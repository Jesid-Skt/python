calificacion1 = float(input("Ingrese la primera calificación: "))
calificacion2 = float(input("Ingrese la segunda calificación: "))
calificacion3 = float(input("Ingrese la tercera calificación: "))

promedio = (calificacion1 + calificacion2 + calificacion3) / 3

print("Calificación 1:", calificacion1)
print("Calificación 2:", calificacion2)
print("Calificación 3:", calificacion3)
print("Promedio:", promedio)